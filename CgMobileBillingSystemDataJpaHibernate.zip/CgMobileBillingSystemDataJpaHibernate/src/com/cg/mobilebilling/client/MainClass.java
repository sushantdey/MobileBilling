package com.cg.mobilebilling.client;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.services.BillingServices;
public class MainClass {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws BillingServicesDownException{
		ApplicationContext context=new ClassPathXmlApplicationContext("projectBeans.xml");
		BillingServices billingService=(BillingServices) context.getBean("billingServices");
		List<Plan> listPlan=billingService.getPlanAllDetails();
		for(Plan plan:listPlan)
		System.out.println(plan.toString());
	}
}