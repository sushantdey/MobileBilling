package com.cg.mobilebilling.client;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
public class MainClass {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException{
		ApplicationContext context=new ClassPathXmlApplicationContext("projectBeans.xml");
		BillingServices billingService=(BillingServices) context.getBean("billingServices");
		/*List<Plan> listPlan=billingService.getPlanAllDetails();
		for(Plan plan:listPlan)
		System.out.println(plan.toString());*/
		
		Customer customer=new Customer("Ashav","Kumar","ashav21011996@gmail.com","21/01/1996",new Address(101418,"Pune","Maharashtra"));
		System.out.println(billingService.acceptCustomerDetails(customer));
		
		long mobileNo=billingService.openPostpaidMobileAccount(1001, 1);
		System.out.println(mobileNo);
	}
}