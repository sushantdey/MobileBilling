package com.cg.mobilebilling.daoservices;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.mobilebilling.beans.PostpaidAccount;
@Qualifier("JpaRepository")
public interface PostpaidAccountDAOServices extends JpaRepository<PostpaidAccount, Long>{
}
